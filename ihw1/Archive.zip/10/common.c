#include "common.h"

const char FIFO_RAW_PATHNAME[] = "raw.fifo";
const char FIFO_PROCESSED_PATHNAME[] = "processed.fifo";
